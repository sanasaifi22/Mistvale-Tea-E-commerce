# Mistvale Tea Co.

A responsive one-page tea store created as part of the MeroxIO Web Developer assessment.

## Features

- Responsive tea store UI
- Product search
- Category filtering
- Product sorting
- Product quick view
- Add to Cart
- Quantity and stock-limit handling
- WELCOME10 coupon
- Shipping calculation
- Pincode delivery check
- Checkout form integration
- Responsive mobile layout

## Technologies

- HTML5
- CSS3
- JavaScript
- Google Fonts

## Project Structure

```text
Mistvale-Assessment/
├── index.html
├── images/
├── NOTES.md
├── PROMPTS.md
└── README.md
