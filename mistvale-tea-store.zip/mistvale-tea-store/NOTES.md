# Mistvale Tea Co. – Assessment Notes

## Changes Made
- Improved product card and button styling.
- Fixed product search.
- Fixed category filtering.
- Fixed sorting.
- Fixed Add to Cart functionality.
- Added quantity and stock-limit handling.
- Added WELCOME10 coupon functionality.
- Fixed shipping calculation.
- Added pincode delivery checking.
- Fixed checkout form submission.
- Improved responsive and mobile usability.

## Testing
- Tested product search.
- Tested category filters.
- Tested search with filters.
- Tested sorting.
- Tested Add to Cart.
- Tested quantity and stock limits.
- Tested WELCOME10 coupon.
- Tested shipping calculation.
- Tested pincode checking.
- Tested checkout flow.

## AI Assistance
AI tools were used to help debug JavaScript, understand the existing code, and improve CSS/UI. All changes were manually reviewed and tested.

## Known Limitations
- The checkout endpoint provided in the assessment is not a live backend, so submitting the checkout form may result in an error page.

## AI-Assisted Debugging

During implementation, AI assistance was used to identify JavaScript and CSS issues. The suggested changes were reviewed, applied, and manually tested in the browser.