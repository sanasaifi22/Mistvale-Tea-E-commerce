# AI Prompt Log

## Prompt 1
"ab dekho thikh"

### Outcome
Reviewed the current JavaScript and identified the shipping calculation issue.

## Prompt 2
"kah pr h"

### Outcome
Explained exactly where the shipping calculation code needed to be changed.

## Prompt 3
"ho gya"

### Outcome
Confirmed the shipping calculation was corrected and moved to testing.

## Prompt 4
"add to acrt sahis e nhi arha h sare box main"

### Outcome
Identified the CSS issue causing the Add to Cart button to appear inconsistently and provided a CSS fix.

## Prompt 5
"Prompt aminkya"

### Outcome
Clarified what should be included in PROMPTS.md.